#include <iostream>

using namespace std;

int bloggium[500][500];
int yeayenum[500][500];

int bl[500][500];
int ye[500][500];

int n, m;

int main() {

	while (cin >> n >> m) {

		if (n == 0) return 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cin >> yeayenum[i][j];
			}
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cin >> bloggium[i][j];
			}
		}

		for (int i = 0; i < n; i++) {
			ye[i][0] = yeayenum[i][0];
			for (int j = 1; j < m; j++) {
				ye[i][j] = ye[i][j - 1] + yeayenum[i][j];
			}
		}

		for (int i = 0; i < m; i++) {
			bl[0][i] = bloggium[0][i];
			for (int j = 1; j < n; j++) {
				bl[j][i] = bl[j - 1][i] + bloggium[j][i];
			}
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << bl[i][j] << " ";
			}
			cout << endl;
		}
		cout << endl;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				cout << ye[i][j] << " ";
			}
			cout << endl;
		}

	};




}